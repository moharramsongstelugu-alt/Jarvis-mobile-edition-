# J.A.R.V.I.S Mobile Edition

A phone-friendly personal AI assistant starter project with a dark sci-fi interface, text chat, browser speech input, text-to-speech, image analysis, a Progressive Web App (PWA) manifest, and a Cloudflare Worker backend for Gemini.

> This is an independent starter project inspired by the workflow described in the GrowthOS Telugu Episode 10 PDF. It is not an official product of Marvel, Google, Cloudflare, or GrowthOS Telugu.

## Features

- Responsive mobile-first interface
- Gemini-powered chat through a server-side Cloudflare Worker
- Image upload and analysis
- Browser speech recognition where supported
- Text-to-speech replies
- PWA install support and basic app-shell caching
- Optional daily Telegram check-in via a Cloudflare Cron Trigger
- GitHub Pages frontend deployment
- MIT license

## Project structure

```text
jarvis-mobile-edition/
├── frontend/
│   ├── index.html
│   ├── script.js
│   ├── style.css
│   ├── manifest.json
│   ├── sw.js
│   └── assets/
│       └── icon.svg
├── functions/
│   └── worker.js
├── .gitignore
├── LICENSE
├── README.md
└── wrangler.toml
```

## Before you start

You need:
- An Android phone and Chrome
- A GitHub account
- A Google AI Studio API key with access to a supported Gemini model
- A Cloudflare account

The AI backend requires internet access. The cached interface may load offline, but AI chat and image analysis will not work offline.

## 1. Create a GitHub repository

1. Create a new repository named `jarvis-mobile-edition`.
2. Upload the files and folders in this project, preserving the folder structure.
3. Do not upload API keys, `.env` files, or private tokens.

You can do this from the GitHub website on Android, or use a mobile code editor / Git client. If uploading from a phone, upload the individual files and keep the paths as shown above.

## 2. Deploy the backend on Cloudflare Workers

The frontend must not contain the Gemini API key. Keep the key in a Worker secret.

### Dashboard deployment

1. Open Cloudflare Dashboard → **Workers & Pages**.
2. Create a Worker named `jarvis-mobile-edition-api`.
3. Paste the contents of `functions/worker.js` into the Worker editor, then deploy.
4. In the Worker settings, add a secret named `GEMINI_API_KEY` with your Gemini API key.
5. Optionally add a variable `GEMINI_MODEL` with a model available to your Google AI account. The default in this starter is `gemini-2.0-flash`; model availability can change, so verify it in your account.
6. Optionally set `ALLOWED_ORIGINS` to your exact GitHub Pages origin, for example `https://YOUR-USERNAME.github.io`. Do not include a path. For a project site, the origin is still `https://YOUR-USERNAME.github.io`.
7. Deploy again after changing secrets or variables.
8. Open the Worker URL in a browser. A healthy Worker responds with JSON showing `"status":"ok"`.

**Security note:** if `ALLOWED_ORIGINS` is omitted, this starter permits any browser origin. Configure it for your site before public use. CORS is not authentication and does not prevent direct API requests. Add rate limiting and usage limits before sharing widely.

### Optional CLI deployment

If you have a computer or a compatible terminal environment, install Wrangler and run:

```bash
npm install -g wrangler
wrangler login
wrangler secret put GEMINI_API_KEY
wrangler deploy
```

Run these commands from the project root. When prompted for `GEMINI_API_KEY`, paste the key privately into the terminal prompt. Do not commit it.

The `wrangler.toml` file defines the Worker entry point and an optional daily cron. Cloudflare's dashboard settings can also be used to configure secrets.

## 3. Publish the frontend with GitHub Pages

1. In your repository, open **Settings → Pages**.
2. Choose **Deploy from a branch**.
3. Select branch `main` and folder `/ (root)` only if you move/copy the frontend files to the repository root. This repository includes `.github/workflows/pages.yml`, which publishes the `frontend/` directory automatically.
4. Recommended for this project: keep the folder structure as-is and use the included `.github/workflows/pages.yml` workflow. In Settings → Pages, set the source to **GitHub Actions**. The workflow publishes `frontend/`.
5. Save and wait for the Pages URL to become available.

### Easiest phone-only setup

For a simple GitHub Pages setup, copy the contents of `frontend/` (`index.html`, `style.css`, `script.js`, `manifest.json`, `sw.js`, and `assets/`) into the repository root. Then configure Pages to deploy from `main` and `/(root)`. The backend stays in `functions/worker.js`.

## 4. Connect the app to the Worker

1. Open your published GitHub Pages site in Chrome.
2. Tap the settings gear.
3. Paste your deployed Worker URL, such as `https://jarvis-mobile-edition-api.YOUR-SUBDOMAIN.workers.dev`.
4. Save settings.
5. Send a test message.

The Gemini key is not entered into the frontend. It stays in the Worker secret.

## 5. Install it on Android

1. Open the HTTPS GitHub Pages site in Chrome.
2. Open the three-dot menu.
3. Tap **Add to Home screen** or **Install app**, depending on Chrome's menu.
4. Confirm the install.
5. Launch J.A.R.V.I.S from the home screen.

Speech recognition support varies by browser, device, language, and permissions. If voice input fails, type your message instead.

## 6. Optional Telegram daily check-in

The Worker includes a simple scheduled Telegram check-in, not a live news or weather briefing.

1. Create a bot with Telegram's `@BotFather`.
2. Obtain the chat ID for the intended recipient.
3. In Cloudflare Worker settings, add secrets `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`.
4. Ensure the Cron Trigger `30 1 * * *` is enabled. Cloudflare cron expressions use UTC; 01:30 UTC is 07:00 IST.
5. Deploy and test the Worker.

The scheduled function sends a short daily priority-setting message. It does not automatically fetch news, weather, or crypto data.

## Security checklist before making the repo public

- [ ] `GEMINI_API_KEY` is a Cloudflare secret, not in frontend JavaScript.
- [ ] Telegram tokens and chat IDs are not committed.
- [ ] `ALLOWED_ORIGINS` is set to the intended frontend origin.
- [ ] Usage limits / rate limiting are configured before public sharing.
- [ ] The app is tested on Android Chrome.
- [ ] The repository contains no private logs or personal data.
- [ ] README claims match features actually tested.

## Test checklist

- [ ] Worker root URL responds with status `ok`.
- [ ] Chat returns an AI response.
- [ ] Image upload returns an image analysis.
- [ ] Voice input works on the target browser, or text input is available.
- [ ] Text-to-speech works when enabled.
- [ ] PWA installs from HTTPS.
- [ ] Telegram check-in arrives if optional Telegram secrets are configured.

## Release `v1.0.0-Legacy`

Following the Episode 10 release naming:

1. Confirm the test checklist is complete.
2. Open the repository's **Releases** section.
3. Choose **Draft a new release**.
4. Create tag `v1.0.0-Legacy`.
5. Use title `J.A.R.V.I.S Mobile Edition - Grand Finale`.
6. Describe the tested frontend, Worker backend, and optional Telegram automation.
7. Mark it as the latest release and publish.

Do not call the release production-ready until you have tested it and configured abuse protection and usage limits.

## Troubleshooting

- **“Connect your backend first”**: set the Worker URL in app settings.
- **CORS / Origin not allowed**: set `ALLOWED_ORIGINS` to the exact site origin, with no trailing path.
- **Gemini key error**: add `GEMINI_API_KEY` as a Worker secret and redeploy.
- **Model not found**: set `GEMINI_MODEL` to a model currently available to your account.
- **Voice not supported**: use a recent Chrome version or type instead.
- **Image too large**: choose an image smaller than 5 MB.

## License

Released under the MIT License. See [LICENSE](LICENSE).

## Credits

This project follows the general open-source workflow described in the user's uploaded *GrowthOS Telugu — J.A.R.V.I.S Mobile Edition, Episode 10: The Legacy* PDF. Product names and services belong to their respective owners.
