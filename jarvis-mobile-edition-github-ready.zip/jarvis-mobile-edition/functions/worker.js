/**
 * J.A.R.V.I.S Mobile Edition — Cloudflare Worker
 * Gemini API key must be stored as a Worker secret named GEMINI_API_KEY.
 * Optional Telegram automation secrets: TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.
 */

const DEFAULT_MODEL = "gemini-2.0-flash";
const MAX_BODY_BYTES = 7 * 1024 * 1024;
const MAX_HISTORY = 20;
const SYSTEM_INSTRUCTION = `You are J.A.R.V.I.S, a helpful personal AI assistant. Be clear, practical, and honest about uncertainty. Do not claim to control the user's phone or perform actions you cannot actually perform.`;

function json(data, status = 200, origin = "*") {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin"
    }
  });
}
function allowedOrigin(request, env) {
  const origin = request.headers.get("Origin") || "";
  const allowed = (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (!allowed.length) return "*"; // Set ALLOWED_ORIGINS for a production deployment.
  return allowed.includes(origin) ? origin : null;
}
function toGeminiHistory(history = []) {
  return history.slice(-MAX_HISTORY).filter(item => ["user", "assistant"].includes(item.role) && typeof item.content === "string")
    .map(item => ({ role: item.role === "assistant" ? "model" : "user", parts: [{ text: item.content.slice(0, 12000) }] }));
}
async function askGemini(contents, env) {
  if (!env.GEMINI_API_KEY) throw new Error("Server is missing GEMINI_API_KEY. Add it as a Cloudflare Worker secret.");
  const model = env.GEMINI_MODEL || DEFAULT_MODEL;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || `Gemini request failed (${response.status})`;
    throw new Error(message);
  }
  const reply = data?.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("").trim();
  if (!reply) throw new Error("Gemini returned no text. Check the model name, API key, and account limits.");
  return reply;
}
function parseDataUrlBase64(image) {
  if (typeof image !== "string" || image.length > 6 * 1024 * 1024) throw new Error("Image is missing or too large.");
  return image;
}

export default {
  async fetch(request, env) {
    const origin = allowedOrigin(request, env);
    if (origin === null) return new Response("Origin not allowed", { status: 403 });
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: {
      "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type", "Vary": "Origin"
    }});
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") return json({ name: "J.A.R.V.I.S Mobile Edition API", status: "ok" }, 200, origin);
    if (request.method !== "POST" || !["/api/chat", "/api/vision"].includes(url.pathname)) {
      return json({ error: "Not found" }, 404, origin);
    }
    const declaredLength = Number(request.headers.get("Content-Length") || 0);
    if (declaredLength > MAX_BODY_BYTES) return json({ error: "Request too large." }, 413, origin);
    try {
      const body = await request.json();
      const message = typeof body.message === "string" ? body.message.trim().slice(0, 12000) : "";
      if (!message) return json({ error: "Please enter a message." }, 400, origin);
      const history = Array.isArray(body.history) ? body.history : [];
      const contents = toGeminiHistory(history);
      if (url.pathname === "/api/vision") {
        const image = parseDataUrlBase64(body.image);
        const mimeType = typeof body.mimeType === "string" && /^image\/(png|jpeg|webp|gif)$/.test(body.mimeType) ? body.mimeType : "image/jpeg";
        contents.push({ role: "user", parts: [{ text: message }, { inlineData: { mimeType, data: image } }] });
      } else {
        contents.push({ role: "user", parts: [{ text: message }] });
      }
      const reply = await askGemini(contents, env);
      return json({ reply }, 200, origin);
    } catch (error) {
      return json({ error: error?.message || "Unexpected server error." }, 500, origin);
    }
  },
  async scheduled(event, env, ctx) {
    // Optional daily Telegram briefing. Configure TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.
    // This sends a simple scheduled check-in message; it is not a personalized news/weather feed.
    if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return;
    const text = "Good morning! Your J.A.R.V.I.S daily check-in is ready. Set your top 3 priorities and start with the most important task.";
    const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text })
    });
    if (!response.ok) console.error("Telegram scheduled message failed:", response.status);
  }
};
