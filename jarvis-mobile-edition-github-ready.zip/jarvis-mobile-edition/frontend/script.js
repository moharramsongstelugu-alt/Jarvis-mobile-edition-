const $ = (id) => document.getElementById(id);
const chat = $("chat");
const input = $("messageInput");
const busy = $("busy");
const imageInput = $("imageInput");
const imagePreview = $("imagePreview");
const previewImg = $("previewImg");
const settingsDialog = $("settingsDialog");

let selectedImage = null;
let history = [];
let config = { apiBase: "", speakReplies: false };

try {
  const saved = JSON.parse(localStorage.getItem("jarvis-settings") || "{}");
  config = { ...config, ...saved };
} catch {}
$("apiBase").value = config.apiBase || "";
$("speakReplies").checked = !!config.speakReplies;

function saveConfig() {
  config.apiBase = $("apiBase").value.trim().replace(/\/+$/, "");
  config.speakReplies = $("speakReplies").checked;
  localStorage.setItem("jarvis-settings", JSON.stringify(config));
  settingsDialog.close();
  addMessage("assistant", "Settings saved. Add your deployed Cloudflare Worker URL to connect the AI backend.");
}

$("settingsBtn").addEventListener("click", () => settingsDialog.showModal());
$("saveSettings").addEventListener("click", (event) => {
  event.preventDefault();
  saveConfig();
});
$("attachBtn").addEventListener("click", () => imageInput.click());
imageInput.addEventListener("change", () => {
  const file = imageInput.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) return alert("Choose an image file.");
  if (file.size > 5 * 1024 * 1024) return alert("Please choose an image smaller than 5 MB.");
  const reader = new FileReader();
  reader.onload = () => {
    selectedImage = { dataUrl: reader.result, mimeType: file.type };
    previewImg.src = reader.result;
    imagePreview.classList.remove("hidden");
  };
  reader.readAsDataURL(file);
});
$("removeImage").addEventListener("click", clearImage);
function clearImage() {
  selectedImage = null;
  imageInput.value = "";
  previewImg.removeAttribute("src");
  imagePreview.classList.add("hidden");
}

document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => {
    input.value = button.dataset.prompt || "";
    input.focus();
    autoResize();
  });
});

function autoResize() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 150) + "px";
}
input.addEventListener("input", autoResize);
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("composer").requestSubmit();
  }
});

function addMessage(role, text, imageUrl = null) {
  const row = document.createElement("div");
  row.className = `message ${role === "user" ? "user" : "assistant"}`;
  if (role !== "user") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "J";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (imageUrl) {
    const img = document.createElement("img");
    img.src = imageUrl;
    img.alt = "Image attached to message";
    bubble.appendChild(img);
  }
  const textNode = document.createElement("div");
  textNode.textContent = text;
  bubble.appendChild(textNode);
  if (role !== "user" && text) {
    const actions = document.createElement("div");
    actions.className = "message-actions";
    const copy = document.createElement("button");
    copy.className = "mini-btn";
    copy.textContent = "Copy";
    copy.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(text); copy.textContent = "Copied"; }
      catch { copy.textContent = "Copy unavailable"; }
    });
    const speak = document.createElement("button");
    speak.className = "mini-btn";
    speak.textContent = "Read aloud";
    speak.addEventListener("click", () => speakText(text));
    actions.append(copy, speak);
    bubble.appendChild(actions);
  }
  row.appendChild(bubble);
  chat.appendChild(row);
  row.scrollIntoView({ behavior: "smooth", block: "end" });
}

function speakText(text) {
  if (!("speechSynthesis" in window)) return alert("Text-to-speech is not supported by this browser.");
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-IN";
  window.speechSynthesis.speak(utterance);
}

function showBusy(value) {
  busy.classList.toggle("hidden", !value);
  $("sendBtn").disabled = value;
}

async function sendToWorker(message, image) {
  if (!config.apiBase) {
    throw new Error("Connect your backend first: open Settings and enter your deployed Cloudflare Worker URL. See README.md for setup.");
  }
  const endpoint = image ? "/api/vision" : "/api/chat";
  const payload = image
    ? { message, image: image.dataUrl.split(",")[1], mimeType: image.mimeType, history }
    : { message, history };
  const response = await fetch(config.apiBase + endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
  if (typeof data.reply !== "string") throw new Error("The backend returned an unexpected response.");
  return data.reply;
}

$("composer").addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  if (!message && !selectedImage) return;
  const image = selectedImage;
  addMessage("user", message || "Please analyze this image.", image?.dataUrl || null);
  input.value = "";
  autoResize();
  clearImage();
  $("welcome").classList.add("hidden");
  history.push({ role: "user", content: message || "Please analyze this image." });
  showBusy(true);
  try {
    const reply = await sendToWorker(message || "Please analyze this image.", image);
    addMessage("assistant", reply);
    history.push({ role: "assistant", content: reply });
    if (history.length > 20) history = history.slice(-20);
    if (config.speakReplies) speakText(reply);
  } catch (error) {
    const msg = error?.message || "Something went wrong.";
    addMessage("assistant", `I couldn't complete that request.\n\n${msg}`);
  } finally {
    showBusy(false);
  }
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
$("voiceBtn").addEventListener("click", () => {
  if (!SpeechRecognition) return alert("Voice input is not supported in this browser. Try the latest Chrome.");
  const recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  $("voiceBtn").textContent = "🎙 Listening…";
  recognition.onresult = (event) => {
    input.value = event.results[0][0].transcript;
    autoResize();
    input.focus();
  };
  recognition.onerror = (event) => alert(`Voice input error: ${event.error}`);
  recognition.onend = () => { $("voiceBtn").textContent = "🎙 Voice"; };
  recognition.start();
});

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
